# PIP2025_GR3
Group 3 of the inter-promo project of master SID from university paul sabatier (Toulouse, France) in 2025. We worked on the relationship between french people and television.
